# BuildByte.buzz

Interactive BuildByte.buzz waitlist for Cloudflare Pages + Pages Functions + Loops.

## Local

```bash
npm install
cp .env.example .env
# add LOOPS_API_KEY and LOOPS_MAILING_LIST_ID
npm run dev
```

## Cloudflare

Create/connect a Pages project and add encrypted secrets in **Workers & Pages → your project → Settings → Variables and Secrets**:

- `LOOPS_API_KEY`
- `LOOPS_MAILING_LIST_ID`

Do not put secrets in frontend code or commit `.env`.

Deploy with:

```bash
npm run deploy
```

The `/functions/api/waitlist.js` function handles `POST /api/waitlist` and sends contacts to Loops server-side.
